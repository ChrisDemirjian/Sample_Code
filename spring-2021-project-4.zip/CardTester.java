public class CardTester{

    // this class must remain unchanged
    // your code must work with this test class
 
    public static void main(String[] args){
        Card c = new Card(1,13);
        System.out.println(c);
    }
}
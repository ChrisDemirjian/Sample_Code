import java.util.ArrayList;
import java.util.Collections;

public class SortTester{

    // this class must remain unchanged
    // your code must work with this test class
 
    public static void main(String[] args){
    
        Card s1 = new Card(1, 1);
        Card s2 = new Card(1, 2);
        Card s3 = new Card(1, 3);
        Card s4 = new Card(1, 4);
        Card d1 = new Card(3, 13);
        
        ArrayList<Card> hand= new ArrayList<>();
        
        hand.add(d1);
        hand.add(s1);
        hand.add(s2);
        hand.add(s4);
        hand.add(s3);
        
        
        Collections.sort(hand);
        
        System.out.println(hand);
        
    }
}


public class DeckTester{

    // this class must remain unchanged
    // your code must work with this test class
 
    public static void main(String[] args){
        /*Deck d = new Deck();
        
        for (int card=0; card<53; card++){
            System.out.println(d.cards[card]);
        }
        
        d.shuffle();
        for (int card=0; card<52; card++){
            System.out.println(d.cards[card]);
        }
        System.out.println("dealing");
        System.out.println(d.deal());
        System.out.println(d.deal());
        System.out.println(d.deal());
        System.out.println(d.deal());*/
    }
}

/*  for (int card=0; card<52; card++){
        System.out.println(cards.getDeck()[card]);
    }
    public Card[] getDeck(){
        return cards;
    }
 * 
 * /
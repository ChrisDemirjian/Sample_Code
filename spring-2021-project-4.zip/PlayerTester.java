public class PlayerTester{

    // this class must remain unchanged
    // your code must work with this test class
 
    public static void main(String[] args){
        Player p = new Player();
        System.out.println(p.getBankroll());
        p.bets(5);
        System.out.println(p.getBankroll());
        p.winnings(10);
        System.out.println(p.getBankroll());
    }
}